MM_TCP = 1
MM_UDP = 2

MM_UNKNOWN = -1

MM_MAX = -2 #Cannot be in [0,9] because these are already valid arguments for compression.
